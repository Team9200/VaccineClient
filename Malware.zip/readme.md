1. server start
> node server.js

2. client start
> node client-webserver.js

3. enjoy!